<?php
$currLesson = "3";
$nextChapter = "3";
require_once('../includes/SetLesson.inc');
$TestNbr    = '902 ';
$Result     = 'P';
require_once('../includes/SetQuizResult.inc');
header("Location: LS03PQa894kL4/presentation.html");
?>
