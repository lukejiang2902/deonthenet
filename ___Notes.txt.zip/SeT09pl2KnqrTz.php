<?php
$currLesson = "9";
$nextChapter = "9";
require_once('../includes/SetLesson.inc');
$TestNbr    = '908 ';
$Result     = 'P';
require_once('../includes/SetQuizResult.inc');
header("Location: LS09o0pQErst4/presentation.html");
?>
