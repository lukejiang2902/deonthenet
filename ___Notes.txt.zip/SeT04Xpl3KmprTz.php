<?php
$currLesson = "4";
$nextChapter = "4X";
require_once('../includes/SetLesson.inc');
$TestNbr    = '904 ';
$Result     = 'F';
require_once('../includes/SetQuizResult.inc');
header("Location: LS04f24PsJz61/presentation.html");
?>
