<?php
$currLesson = "2";
$nextChapter = "2X";
require_once('../includes/SetLesson.inc');
$TestNbr    = '902 ';
$Result     = 'F';
require_once('../includes/SetQuizResult.inc');
header("Location: LS02a7493jQ55/presentation.html");
?>
