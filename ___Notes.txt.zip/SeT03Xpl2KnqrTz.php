<?php
$currLesson = "3";
$nextChapter = "3X";
require_once('../includes/SetLesson.inc');
$TestNbr    = '903 ';
$Result     = 'F';
require_once('../includes/SetQuizResult.inc');
header("Location: LS03PQa894kL4/presentation.html");
?>
