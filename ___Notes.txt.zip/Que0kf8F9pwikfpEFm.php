<?php
//******************************************************************************
//    This script sets the indicators to show the student has passed the       *
//    final quiz and sends an e-mail to the driving school                     *
//                                                                             *
//*********************************************Last Modified: July. 22, 2011 ***

require_once('../includes/GetDMVcookie.inc');
require_once('../includes/conndb.inc');

// ********************************************** see if the student is finished
$sql = "SELECT *
        FROM   ststats
        WHERE  U_StudentLogin = '$LoginID'
        AND    U_DMVSchoolNbr = '$SchoolNbr'
        ";
$result = mysql_query($sql);
if (!$result) {
//    echo "Could not successfully run query ($sql) from DB: " . mysql_error();
    echo "Could not successfully run query ($sql) from DB: ";
    mysql_close($conn);
    exit;
    }
if (mysql_num_rows($result) == 0) {
    print "System Error Code: Q0S7 - Please call the Adminstrator at DMV-DriversEd.com<br>";
    mysql_close($conn);
    exit;
    }
$row = mysql_fetch_array($result);
$U_gotoLesson = $row["U_gotoLesson"];

if ($U_gotoLesson == '12') {
      print "<h2>Remember, you are finished!</h2>";
      mysql_close($conn);
      exit;
      };

// ********************************************** see if the questionaire exists
$sql = "SELECT *
        FROM   quest
        WHERE  Q_StudentLogin = '$LoginID'
        AND    Q_DMVSchoolNbr = '$SchoolNbr'
        ";
$result = mysql_query($sql);
if (!$result) {
//    echo "Could not successfully run query ($sql) from DB: " . mysql_error();
    echo "Could not successfully run query ($sql) from DB: ";
    mysql_close($conn);
    exit;
    }

if (mysql_num_rows($result) >= 1) {      // bypass the questionaire; it's already there
       header("Location: LS10Z63o9fs0f/qwzA309fgvQWnyq99eisj/QZFN39pqmt4K7A/Final/quiz.html");
       mysql_close($conn);
       exit;
       };
header("Location: Que1kf8F9qwlkfgEFn.php");
?>
