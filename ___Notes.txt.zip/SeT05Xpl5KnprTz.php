<?php
$currLesson = "5";
$nextChapter = "5X";
require_once('../includes/SetLesson.inc');
$TestNbr    = '905 ';
$Result     = 'F';
require_once('../includes/SetQuizResult.inc');
header("Location: LS05Aplwi672Z/presentation.html");
?>
