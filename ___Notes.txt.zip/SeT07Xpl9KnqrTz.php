<?php
$currLesson = "7";
$nextChapter = "7X";
require_once('../includes/SetLesson.inc');
$TestNbr    = '907 ';
$Result     = 'F';
require_once('../includes/SetQuizResult.inc');
header("Location: LS07169hnD0fw/presentation.html");
?>
