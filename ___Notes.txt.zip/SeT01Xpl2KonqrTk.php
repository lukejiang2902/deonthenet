<?php
//*************for testing only **********************
//$SchoolNbr  = 'NV9991';
//$LoginID    = 'fta';
//***************END testing *************************

$currLesson = "1";
$nextChapter = "1X";
require_once('../includes/SetLesson.inc');
$TestNbr    = '901 ';
$Result     = 'F';
require_once('../includes/SetQuizResult.inc');
header("Location: LS0139x4KM17S/presentation.html");
?>
