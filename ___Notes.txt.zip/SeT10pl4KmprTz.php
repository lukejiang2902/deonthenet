<?php
$currLesson = "10";
$nextChapter = "10";
require_once('../includes/SetLesson.inc');
$TestNbr    = '909 ';
$Result     = 'P';
require_once('../includes/SetQuizResult.inc');
header("Location: LS10563hG230f/presentation.html");
?>
