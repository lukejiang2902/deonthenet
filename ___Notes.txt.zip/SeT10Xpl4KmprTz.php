<?php
$currLesson = "10";
$nextChapter = "10X";
require_once('../includes/SetLesson.inc');
$TestNbr    = '910 ';
$Result     = 'F';
require_once('../includes/SetQuizResult.inc');
header("Location: LS10563hG230f/presentation.html");
?>
