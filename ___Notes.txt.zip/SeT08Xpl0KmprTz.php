<?php
$currLesson = "8";
$nextChapter = "8X";
require_once('../includes/SetLesson.inc');
$TestNbr    = '908 ';
$Result     = 'F';
require_once('../includes/SetQuizResult.inc');
header("Location: LS08WefTgk62t/presentation.html");
?>
