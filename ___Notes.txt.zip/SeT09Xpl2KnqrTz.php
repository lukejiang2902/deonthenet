<?php
$currLesson = "9";
$nextChapter = "9X";
require_once('../includes/SetLesson.inc');
$TestNbr    = '909 ';
$Result     = 'F';
require_once('../includes/SetQuizResult.inc');
header("Location: LS09o0pQErst4/presentation.html");
?>
