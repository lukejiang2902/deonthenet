<?php
$currLesson = "6";
$nextChapter = "6X";
require_once('../includes/SetLesson.inc');
$TestNbr    = '906 ';
$Result     = 'F';
require_once('../includes/SetQuizResult.inc');
header("Location: LS06T37Lkmq9f/presentation.html");
?>
